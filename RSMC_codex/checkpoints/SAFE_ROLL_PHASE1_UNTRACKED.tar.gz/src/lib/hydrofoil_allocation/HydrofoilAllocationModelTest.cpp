/****************************************************************************
 *
 *   Copyright (c) 2026 PX4 Development Team. All rights reserved.
 *
 ****************************************************************************/

#include <gtest/gtest.h>

#include "HydrofoilAllocationModel.hpp"

#include <mathlib/mathlib.h>

#include <cmath>
#include <chrono>
#include <cstdio>

using hydrofoil::AllocationCommand;
using hydrofoil::AllocationContext;
using hydrofoil::AllocationSolution;
using hydrofoil::HydrofoilAllocationModel;
using matrix::SquareMatrix;
using matrix::Vector2f;
using matrix::Vector3f;
using matrix::Vector4f;

namespace
{
AllocationContext defaultContext()
{
	AllocationContext context{};
	context.lift_coefficient = 2.f;
	context.speed_squared = 9.f;
	context.body_pitch = 0.08f;
	context.max_hydrofoil_angle = 1.134464f;
	context.max_thruster_thrust = 30.f;
	context.available_thruster_thrust = 30.f;
	const float values[4][3] {
		{0.f, 0.f, 30.f},
		{-10.f, 0.f, 0.f},
		{0.f, 0.f, -30.f},
		{10.f, 0.f, 0.f}
	};
	context.virtual_control_matrix = matrix::Matrix<float, 4, 3>(values);
	return context;
}

struct LegacySolution {
	float delta_left;
	float delta_right;
	float thrust_left;
	float thrust_right;
};

Vector2f legacyResidual(const Vector2f &x, const AllocationContext &context, float force_x, float force_z)
{
	Vector2f out;
	out(0) = force_x - context.lift_coefficient * context.speed_squared * (x(0) + context.body_pitch)
		 * std::sin(context.body_pitch) - x(1) * std::cos(x(0));
	out(1) = force_z + context.lift_coefficient * context.speed_squared * (x(0) + context.body_pitch)
		 * std::cos(context.body_pitch) + x(1) * std::sin(x(0));
	return out;
}

SquareMatrix<float, 2> legacyJacobian(const Vector2f &x, const AllocationContext &context)
{
	SquareMatrix<float, 2> J;
	J(0, 0) = -context.lift_coefficient * context.speed_squared * std::sin(context.body_pitch)
		  + x(1) * std::sin(x(0));
	J(0, 1) = -std::cos(x(0));
	J(1, 0) = context.lift_coefficient * context.speed_squared * std::cos(context.body_pitch)
		  + x(1) * std::cos(x(0));
	J(1, 1) = std::sin(x(0));
	return J;
}

void legacySolveSide(Vector2f &x, const AllocationContext &context, float force_x, float force_z)
{
	for (int i = 0; i < 10; ++i) {
		SquareMatrix<float, 2> inverse;
		matrix::inv(legacyJacobian(x, context), inverse);
		const Vector2f step = -inverse * legacyResidual(x, context, force_x, force_z);

		if (step.norm_squared() < 1e-6f) {
			break;
		}

		x += step;
		x(0) = math::constrain(x(0), -context.max_hydrofoil_angle, context.max_hydrofoil_angle);
		x(1) = math::constrain(x(1), 0.f, context.available_thruster_thrust);
	}
}

LegacySolution legacySolve(const AllocationContext &context, const AllocationCommand &command)
{
	const Vector3f u(command.u_phi, command.u_theta, command.u_psi);
	Vector4f forces = context.virtual_control_matrix * u;
	forces += Vector4f(command.force_x * 0.5f, command.force_z * 0.5f,
			 command.force_x * 0.5f, command.force_z * 0.5f);
	float sum_force_x = forces(0) + forces(2);

	if (sum_force_x < 0.f) {
		sum_force_x *= 0.5f;
		forces(0) -= sum_force_x;
		forces(2) -= sum_force_x;
	}

	if (forces(0) < 0.f) {
		forces(2) += forces(0);
		forces(0) = 0.f;

	} else if (forces(2) < 0.f) {
		forces(0) += forces(2);
		forces(2) = 0.f;
	}

	Vector2f left(0.f, command.force_x * 0.5f);
	Vector2f right(0.f, command.force_x * 0.5f);
	legacySolveSide(left, context, forces(0), forces(1));
	legacySolveSide(right, context, forces(2), forces(3));
	return {left(0), right(0), left(1), right(1)};
}
} // namespace

TEST(HydrofoilAllocationModel, LegacyRegressionNormalRegion)
{
	AllocationContext context = defaultContext();
	const AllocationCommand commands[] {
		{20.f, -2.f, 0.f, 0.f, 0.f},
		{30.f, 0.f, 0.3f, 0.f, 0.f},
		{30.f, 0.f, -0.3f, 0.f, 0.f},
		{24.f, 4.f, 0.2f, 0.f, 0.1f},
		{12.f, -4.f, -0.15f, 0.f, -0.1f}
	};

	for (const AllocationCommand &command : commands) {
		const LegacySolution legacy = legacySolve(context, command);
		const AllocationSolution shared = HydrofoilAllocationModel::solve(context, command);
		ASSERT_TRUE(shared.status.valid);
		EXPECT_NEAR(shared.delta_left_commanded, legacy.delta_left, 1e-6f);
		EXPECT_NEAR(shared.delta_right_commanded, legacy.delta_right, 1e-6f);
		EXPECT_NEAR(shared.thrust_left_commanded, legacy.thrust_left, 1e-5f);
		EXPECT_NEAR(shared.thrust_right_commanded, legacy.thrust_right, 1e-5f);
	}
}

TEST(HydrofoilAllocationModel, RegressionAcrossPitchThrottleAndSaturation)
{
	for (float pitch : {-0.2f, 0.f, 0.2f}) {
		for (float available_thrust : {8.f, 20.f, 30.f}) {
			AllocationContext context = defaultContext();
			context.body_pitch = pitch;
			context.available_thruster_thrust = available_thrust;

			for (float u_phi : {-0.8f, -0.2f, 0.f, 0.2f, 0.8f}) {
				const AllocationCommand command{18.f, 0.f, u_phi, 0.f, 0.f};
				const LegacySolution legacy = legacySolve(context, command);
				const AllocationSolution shared = HydrofoilAllocationModel::solve(context, command);
				EXPECT_NEAR(shared.delta_left_commanded, legacy.delta_left, 1e-5f);
				EXPECT_NEAR(shared.delta_right_commanded, legacy.delta_right, 1e-5f);
				EXPECT_NEAR(shared.thrust_left_commanded, legacy.thrust_left, 1e-4f);
				EXPECT_NEAR(shared.thrust_right_commanded, legacy.thrust_right, 1e-4f);
			}
		}
	}
}

TEST(HydrofoilAllocationModel, ForwardAndEffectiveInputAreModelBased)
{
	const AllocationContext context = defaultContext();
	const AllocationCommand command{24.f, 2.f, 0.25f, 0.f, 0.05f};
	const AllocationSolution solution = HydrofoilAllocationModel::solve(context, command);
	ASSERT_TRUE(solution.status.valid);
	const auto forward = HydrofoilAllocationModel::forward(context, solution);
	ASSERT_TRUE(forward.valid);
	EXPECT_NEAR(forward.u_phi_effective_model, command.u_phi, 2e-3f);
	EXPECT_LT(forward.reconstruction_residual, 0.05f);
}

TEST(HydrofoilAllocationModel, AnalyticSensitivityMatchesCentralDifference)
{
	const AllocationContext context = defaultContext();
	const AllocationCommand command{24.f, 0.f, 0.1f, 0.f, 0.f};
	const AllocationSolution solution = HydrofoilAllocationModel::solve(context, command);
	ASSERT_TRUE(solution.status.valid);
	const auto linearization = HydrofoilAllocationModel::linearize(context, solution);
	ASSERT_TRUE(linearization.valid);
	constexpr float epsilon = 1e-3f;
	const AllocationSolution plus = HydrofoilAllocationModel::checkCandidate(context, command, command.u_phi + epsilon);
	const AllocationSolution minus = HydrofoilAllocationModel::checkCandidate(context, command, command.u_phi - epsilon);
	ASSERT_TRUE(plus.status.valid);
	ASSERT_TRUE(minus.status.valid);
	EXPECT_NEAR(linearization.g_left,
		    (plus.delta_left_commanded - minus.delta_left_commanded) / (2.f * epsilon), 2e-3f);
	EXPECT_NEAR(linearization.g_right,
		    (plus.delta_right_commanded - minus.delta_right_commanded) / (2.f * epsilon), 2e-3f);
}

TEST(HydrofoilAllocationModel, InvalidSingularNonFiniteAndNonConverged)
{
	AllocationContext singular = defaultContext();
	singular.lift_coefficient = 0.f;
	const AllocationSolution singular_solution = HydrofoilAllocationModel::solve(singular, {});
	EXPECT_FALSE(singular_solution.status.valid);

	AllocationContext nonfinite = defaultContext();
	nonfinite.speed_squared = NAN;
	EXPECT_FALSE(HydrofoilAllocationModel::solve(nonfinite, {}).status.valid);

	AllocationContext saturated = defaultContext();
	saturated.max_hydrofoil_angle = 0.01f;
	saturated.available_thruster_thrust = 0.1f;
	const AllocationSolution nonconverged = HydrofoilAllocationModel::solve(saturated,
		AllocationCommand{100.f, 100.f, 1.f, 0.f, 0.f});
	EXPECT_FALSE(nonconverged.status.valid);
	EXPECT_NE(nonconverged.status.saturation_mask, 0u);
}

TEST(HydrofoilAllocationModel, CommandedAngleRateInterval)
{
	const auto interval = HydrofoilAllocationModel::commandedAngleInterval(0.2f, -0.2f, 0.6f, 1.f, 0.1f, 0.05f);
	ASSERT_TRUE(interval.valid);
	EXPECT_FLOAT_EQ(interval.left_min, 0.1f);
	EXPECT_FLOAT_EQ(interval.left_max, 0.3f);
	EXPECT_FLOAT_EQ(interval.right_min, -0.3f);
	EXPECT_FLOAT_EQ(interval.right_max, -0.1f);
	EXPECT_FALSE(HydrofoilAllocationModel::commandedAngleInterval(0.f, 0.f, 0.5f, 1.f, 0.f, 0.f).valid);
}

TEST(HydrofoilAllocationModel, HostPerformanceReference)
{
	const AllocationContext context = defaultContext();
	AllocationCommand command{24.f, 0.f, 0.f, 0.f, 0.f};
	constexpr int iterations = 10000;
	uint64_t maximum_ns = 0;
	volatile float sink = 0.f;
	const auto total_start = std::chrono::steady_clock::now();

	for (int i = 0; i < iterations; ++i) {
		command.u_phi = static_cast<float>((i % 101) - 50) * 0.005f;
		const auto start = std::chrono::steady_clock::now();
		const AllocationSolution solution = HydrofoilAllocationModel::solve(context, command);
		const auto forward = HydrofoilAllocationModel::forward(context, solution);
		const auto linearization = HydrofoilAllocationModel::linearize(context, solution);
		const auto stop = std::chrono::steady_clock::now();
		const uint64_t elapsed_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(stop - start).count();
		maximum_ns = math::max(maximum_ns, elapsed_ns);
		sink += solution.delta_left_commanded + forward.u_phi_effective_model + linearization.g_left;
	}

	const auto total_stop = std::chrono::steady_clock::now();
	const uint64_t total_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(total_stop - total_start).count();
	std::printf("HOST_PERF allocation_solve_forward_linearize average_ns=%llu maximum_ns=%llu sink=%f\n",
		    static_cast<unsigned long long>(total_ns / iterations),
		    static_cast<unsigned long long>(maximum_ns), static_cast<double>(sink));
}
