/****************************************************************************
 *
 *   Copyright (c) 2026 PX4 Development Team. All rights reserved.
 *
 ****************************************************************************/

#pragma once

#include <lib/perf/perf_counter.h>

#include <cstdint>

class SafeRollController
{
public:
	enum class Mode : uint8_t {
		Legacy = 0,
		NominalFramework = 1,
		WorstCaseFixedFramework = 2,
		ProposedFramework = 3,
		NoAllocationAblationFramework = 4
	};

	enum class Result : uint8_t {
		LegacyDirect = 0,
		ModeNotImplemented,
		InvalidInput,
		FoilGateDisabled,
		AllocatorInvalid,
		LogicalMappingInvalid
	};

	enum Fault : uint32_t {
		FaultNone = 0,
		TimestampNonMonotonic = 1u << 0,
		DtTooSmall = 1u << 1,
		DtTooLarge = 1u << 2,
		GyroStale = 1u << 3,
		AttitudeStale = 1u << 4,
		QuaternionNonFinite = 1u << 5,
		AngularVelocityNonFinite = 1u << 6,
		AllocatorInvalidFault = 1u << 7,
		FoilGateDisabledFault = 1u << 8,
		ModeNotImplementedFault = 1u << 9,
		ModeOutOfRange = 1u << 10,
		LogicalMappingInvalidFault = 1u << 11
	};

	struct Input {
		uint64_t now{0};
		uint64_t angular_velocity_timestamp_sample{0};
		uint64_t attitude_timestamp{0};
		uint8_t requested_mode{0};
		bool armed{false};
		bool in_stab{false};
		bool quaternion_finite{false};
		bool angular_velocity_finite{false};
		bool allocator_valid{false};
		bool foil_gate_enabled{false};
		bool logical_mapping_valid{false};
		uint8_t attitude_reset_counter{0};
		float manual_roll{0.f};
		float phi_sp{0.f};
		float phi{0.f};
		float p{0.f};
		float legacy_u_roll{0.f};
	};

	struct Output {
		Result result{Result::LegacyDirect};
		uint8_t requested_mode{0};
		uint8_t active_mode{0};
		uint32_t reset_count{0};
		uint32_t fault_flags{0};
		bool healthy{false};
		bool fallback_active{false};
		float dt_raw{0.f};
		float dt_used{0.f};
		float u_legacy{0.f};
		float u_nominal{0.f};
		float u_selected{0.f};
	};

	SafeRollController();
	~SafeRollController();

	void reset();
	Output observeLegacy(const Input &input);
	Output update(const Input &input);

	static bool modeImplemented(uint8_t mode) { return mode == static_cast<uint8_t>(Mode::Legacy); }
	static float bumplessStep(float current, float target, float max_rate, float dt);

private:
	Output evaluate(const Input &input, bool run_candidate_framework);
	void resetForTransition(const Input &input);
	Result nominalFramework(const Input &input, Output &output);
	Result worstCaseFixedFramework(const Input &input, Output &output);
	Result proposedFramework(const Input &input, Output &output);
	Result noAllocationAblationFramework(const Input &input, Output &output);

	perf_counter_t _cycle_perf{nullptr};
	uint64_t _last_sample_timestamp{0};
	uint8_t _last_requested_mode{0};
	uint8_t _last_attitude_reset_counter{0};
	bool _last_armed{false};
	bool _last_in_stab{false};
	bool _initialized{false};
	float _last_selected{0.f};
	uint32_t _reset_count{0};
};
