/****************************************************************************
 *
 *   Copyright (c) 2026 PX4 Development Team. All rights reserved.
 *
 ****************************************************************************/

#include <gtest/gtest.h>

#include "SafeRollController.hpp"
#include "CADRC.h"

#include <mathlib/mathlib.h>

#include <chrono>
#include <cstdio>

namespace
{
SafeRollController::Input validInput()
{
	SafeRollController::Input input{};
	input.now = 1'000'000;
	input.angular_velocity_timestamp_sample = 999'000;
	input.attitude_timestamp = 998'000;
	input.quaternion_finite = true;
	input.angular_velocity_finite = true;
	input.allocator_valid = true;
	input.foil_gate_enabled = true;
	input.logical_mapping_valid = true;
	input.in_stab = true;
	return input;
}
}

TEST(SafeRollController, ModeZeroIsSampleExactDirectPath)
{
	SafeRollController controller;
	auto input = validInput();
	const float legacy_samples[] {0.f, 0.125f, -0.75f, 1.f, -1.f, 0.33333334f};

	for (float legacy : legacy_samples) {
		input.requested_mode = 0;
		input.legacy_u_roll = legacy;
		input.now += 2'500;
		input.angular_velocity_timestamp_sample += 2'500;
		input.attitude_timestamp += 2'500;
		const auto output = controller.observeLegacy(input);
		EXPECT_FLOAT_EQ(output.u_selected, legacy);
		EXPECT_EQ(output.active_mode, 0);
		EXPECT_FALSE(output.fallback_active);
	}
}

TEST(SafeRollController, ModeZeroPreservesLegacyCadrcStateAndOutputSamples)
{
	ADRCController before_selector;
	ADRCController after_selector;
	SafeRollController selector;
	struct Sample {
		float phi;
		float p;
		float roll_sp;
		float dt;
	};
	const Sample samples[] {
		{0.f, 0.f, 0.f, 0.0025f},
		{0.03f, 0.12f, 0.10f, 0.0024f},
		{0.07f, -0.08f, 0.15f, 0.0027f},
		{-0.04f, -0.25f, -0.12f, 0.0025f},
		{0.18f, 0.40f, -0.08f, 0.0030f},
		{-0.12f, 0.05f, 0.20f, 0.0020f}
	};
	auto input = validInput();

	for (const Sample &sample : samples) {
		before_selector.update(sample.phi, sample.roll_sp, sample.p, sample.dt);
		after_selector.update(sample.phi, sample.roll_sp, sample.p, sample.dt);
		const float legacy_before = math::constrain(before_selector.getUc() * 0.001f, -1.f, 1.f);
		const float legacy_after = math::constrain(after_selector.getUc() * 0.001f, -1.f, 1.f);
		input.now += 2'500;
		input.angular_velocity_timestamp_sample += 2'500;
		input.attitude_timestamp += 2'500;
		input.requested_mode = 0;
		input.legacy_u_roll = legacy_after;
		const auto output = selector.observeLegacy(input);
		EXPECT_FLOAT_EQ(legacy_after, legacy_before);
		EXPECT_FLOAT_EQ(output.u_selected, legacy_before);
		EXPECT_FLOAT_EQ(after_selector._Z1(0, 0), before_selector._Z1(0, 0));
		EXPECT_FLOAT_EQ(after_selector._Z1(1, 0), before_selector._Z1(1, 0));
		EXPECT_FLOAT_EQ(after_selector._Z2(0, 0), before_selector._Z2(0, 0));
		EXPECT_FLOAT_EQ(after_selector._Z2(1, 0), before_selector._Z2(1, 0));
	}
}

TEST(SafeRollController, UnimplementedModesFallbackWithoutCandidateOutput)
{
	for (uint8_t mode = 1; mode <= 4; ++mode) {
		SafeRollController controller;
		auto input = validInput();
		input.requested_mode = mode;
		input.armed = true;
		input.legacy_u_roll = 0.42f;
		const auto output = controller.update(input);
		EXPECT_FLOAT_EQ(output.u_selected, input.legacy_u_roll);
		EXPECT_EQ(output.active_mode, 0);
		EXPECT_TRUE(output.fallback_active);
		EXPECT_NE(output.fault_flags & SafeRollController::ModeNotImplementedFault, 0u);
	}
}

TEST(SafeRollController, FreshnessTimestampAndResetFramework)
{
	SafeRollController controller;
	auto input = validInput();
	controller.observeLegacy(input);
	const uint32_t initial_resets = controller.observeLegacy(input).reset_count;
	auto output = controller.observeLegacy(input);
	EXPECT_NE(output.fault_flags & SafeRollController::TimestampNonMonotonic, 0u);
	EXPECT_GT(output.reset_count, initial_resets);

	input.now += 100'000;
	input.angular_velocity_timestamp_sample += 2'500;
	output = controller.observeLegacy(input);
	EXPECT_NE(output.fault_flags & SafeRollController::GyroStale, 0u);
	EXPECT_NE(output.fault_flags & SafeRollController::AttitudeStale, 0u);

	input = validInput();
	input.quaternion_finite = false;
	input.angular_velocity_finite = false;
	output = controller.observeLegacy(input);
	EXPECT_NE(output.fault_flags & SafeRollController::QuaternionNonFinite, 0u);
	EXPECT_NE(output.fault_flags & SafeRollController::AngularVelocityNonFinite, 0u);
}

TEST(SafeRollController, GateAndAllocatorFaultsRejectModes)
{
	SafeRollController controller;
	auto input = validInput();
	input.requested_mode = 3;
	input.foil_gate_enabled = false;
	auto output = controller.update(input);
	EXPECT_EQ(output.result, SafeRollController::Result::FoilGateDisabled);

	input.now += 2'500;
	input.angular_velocity_timestamp_sample += 2'500;
	input.attitude_timestamp += 2'500;
	input.foil_gate_enabled = true;
	input.allocator_valid = false;
	output = controller.update(input);
	EXPECT_EQ(output.result, SafeRollController::Result::AllocatorInvalid);
}

TEST(SafeRollController, UnexpectedLogicalMappingRejectsSafeModes)
{
	SafeRollController controller;
	auto input = validInput();
	input.requested_mode = 2;
	input.logical_mapping_valid = false;
	const auto output = controller.update(input);
	EXPECT_EQ(output.result, SafeRollController::Result::LogicalMappingInvalid);
	EXPECT_EQ(output.active_mode, 0);
	EXPECT_TRUE(output.fallback_active);
	EXPECT_NE(output.fault_flags & SafeRollController::LogicalMappingInvalidFault, 0u);
}

TEST(SafeRollController, BumplessStepIsRateLimited)
{
	EXPECT_FLOAT_EQ(SafeRollController::bumplessStep(0.f, 1.f, 2.f, 0.1f), 0.2f);
	EXPECT_FLOAT_EQ(SafeRollController::bumplessStep(0.f, -1.f, 2.f, 0.1f), -0.2f);
	EXPECT_FLOAT_EQ(SafeRollController::bumplessStep(0.9f, 1.f, 2.f, 0.1f), 1.f);
}

TEST(SafeRollController, HostPerformanceReference)
{
	SafeRollController controller;
	auto input = validInput();
	constexpr int iterations = 10000;
	uint64_t maximum_ns = 0;
	volatile float sink = 0.f;
	const auto total_start = std::chrono::steady_clock::now();

	for (int i = 0; i < iterations; ++i) {
		input.now += 2'500;
		input.angular_velocity_timestamp_sample += 2'500;
		input.attitude_timestamp += 2'500;
		input.legacy_u_roll = static_cast<float>((i % 101) - 50) * 0.01f;
		const auto start = std::chrono::steady_clock::now();
		const auto output = controller.observeLegacy(input);
		const auto stop = std::chrono::steady_clock::now();
		maximum_ns = math::max(maximum_ns, static_cast<uint64_t>(
					       std::chrono::duration_cast<std::chrono::nanoseconds>(stop - start).count()));
		sink += output.u_selected;
	}

	const auto total_stop = std::chrono::steady_clock::now();
	const uint64_t total_ns = std::chrono::duration_cast<std::chrono::nanoseconds>(total_stop - total_start).count();
	std::printf("HOST_PERF safe_roll_mode0_observer average_ns=%llu maximum_ns=%llu sink=%f\n",
		    static_cast<unsigned long long>(total_ns / iterations),
		    static_cast<unsigned long long>(maximum_ns), static_cast<double>(sink));
}
