/****************************************************************************
 *
 *   Copyright (c) 2026 PX4 Development Team. All rights reserved.
 *
 ****************************************************************************/

#include "SafeRollController.hpp"

#include <mathlib/mathlib.h>

#include <cmath>

namespace
{
constexpr float kDtMin = 0.001f;
constexpr float kDtMax = 0.010f;
constexpr uint64_t kGyroStaleUs = 20'000;
constexpr uint64_t kAttitudeStaleUs = 50'000;
}

SafeRollController::SafeRollController() :
#ifndef SAFE_ROLL_DISABLE_PERF
	_cycle_perf(perf_alloc(PC_ELAPSED, "safe_roll: cycle"))
#else
	_cycle_perf(nullptr)
#endif
{
}

SafeRollController::~SafeRollController()
{
#ifndef SAFE_ROLL_DISABLE_PERF
	perf_free(_cycle_perf);
#endif
}

void SafeRollController::reset()
{
	_last_sample_timestamp = 0;
	_last_selected = 0.f;
	++_reset_count;
}

float SafeRollController::bumplessStep(float current, float target, float max_rate, float dt)
{
	if (!std::isfinite(current) || !std::isfinite(target) || !std::isfinite(max_rate) || !std::isfinite(dt)
	    || max_rate < 0.f || dt <= 0.f) {
		return target;
	}

	const float maximum_step = max_rate * dt;
	return current + math::constrain(target - current, -maximum_step, maximum_step);
}

SafeRollController::Result SafeRollController::nominalFramework(const Input &, Output &)
{
	return Result::ModeNotImplemented;
}

SafeRollController::Result SafeRollController::worstCaseFixedFramework(const Input &, Output &)
{
	return Result::ModeNotImplemented;
}

SafeRollController::Result SafeRollController::proposedFramework(const Input &, Output &)
{
	return Result::ModeNotImplemented;
}

SafeRollController::Result SafeRollController::noAllocationAblationFramework(const Input &, Output &)
{
	return Result::ModeNotImplemented;
}

void SafeRollController::resetForTransition(const Input &input)
{
	const bool transition = !_initialized || input.armed != _last_armed || input.in_stab != _last_in_stab
				|| input.requested_mode != _last_requested_mode
				|| input.attitude_reset_counter != _last_attitude_reset_counter;

	if (transition) {
		reset();
		_last_selected = input.legacy_u_roll;
	}

	_last_armed = input.armed;
	_last_in_stab = input.in_stab;
	_last_requested_mode = input.requested_mode;
	_last_attitude_reset_counter = input.attitude_reset_counter;
	_initialized = true;
}

SafeRollController::Output SafeRollController::evaluate(const Input &input, bool run_candidate_framework)
{
#ifndef SAFE_ROLL_DISABLE_PERF
	perf_begin(_cycle_perf);
#endif
	resetForTransition(input);
	Output output{};
	output.requested_mode = input.requested_mode;
	output.reset_count = _reset_count;
	output.u_legacy = input.legacy_u_roll;
	output.u_selected = input.legacy_u_roll;

	if (_last_sample_timestamp != 0) {
		if (input.angular_velocity_timestamp_sample <= _last_sample_timestamp) {
			output.fault_flags |= TimestampNonMonotonic;

		} else {
			output.dt_raw = static_cast<float>(input.angular_velocity_timestamp_sample - _last_sample_timestamp) * 1e-6f;

			if (output.dt_raw < kDtMin) {
				output.fault_flags |= DtTooSmall;

			} else if (output.dt_raw > kDtMax) {
				output.fault_flags |= DtTooLarge;
			}
		}
	}

	if (input.angular_velocity_timestamp_sample == 0 || input.now < input.angular_velocity_timestamp_sample
	    || input.now - input.angular_velocity_timestamp_sample > kGyroStaleUs) {
		output.fault_flags |= GyroStale;
	}

	if (input.attitude_timestamp == 0 || input.now < input.attitude_timestamp
	    || input.now - input.attitude_timestamp > kAttitudeStaleUs) {
		output.fault_flags |= AttitudeStale;
	}

	if (!input.quaternion_finite) {
		output.fault_flags |= QuaternionNonFinite;
	}

	if (!input.angular_velocity_finite) {
		output.fault_flags |= AngularVelocityNonFinite;
	}

	if (input.requested_mode > static_cast<uint8_t>(Mode::NoAllocationAblationFramework)) {
		output.fault_flags |= ModeOutOfRange;
	}

	if (!input.allocator_valid) {
		output.fault_flags |= AllocatorInvalidFault;
	}

	if (run_candidate_framework && !input.logical_mapping_valid) {
		output.fault_flags |= LogicalMappingInvalidFault;
	}

	const uint32_t input_validity_faults = TimestampNonMonotonic | DtTooSmall | DtTooLarge | GyroStale | AttitudeStale
					       | QuaternionNonFinite | AngularVelocityNonFinite | ModeOutOfRange;

	if (run_candidate_framework) {
		if ((output.fault_flags & input_validity_faults) != 0) {
			output.result = Result::InvalidInput;

		} else if (!input.foil_gate_enabled) {
			output.fault_flags |= FoilGateDisabledFault;
			output.result = Result::FoilGateDisabled;

		} else if (!input.allocator_valid) {
			output.result = Result::AllocatorInvalid;

		} else if (!input.logical_mapping_valid) {
			output.result = Result::LogicalMappingInvalid;

		} else {
			switch (static_cast<Mode>(input.requested_mode)) {
			case Mode::NominalFramework:
				output.result = nominalFramework(input, output);
				break;

			case Mode::WorstCaseFixedFramework:
				output.result = worstCaseFixedFramework(input, output);
				break;

			case Mode::ProposedFramework:
				output.result = proposedFramework(input, output);
				break;

			case Mode::NoAllocationAblationFramework:
				output.result = noAllocationAblationFramework(input, output);
				break;

			case Mode::Legacy:
			default:
				output.result = Result::InvalidInput;
				break;
			}

			if (output.result == Result::ModeNotImplemented) {
				output.fault_flags |= ModeNotImplementedFault;
			}
		}

		output.fallback_active = true;
		output.active_mode = static_cast<uint8_t>(Mode::Legacy);

	} else {
		output.result = Result::LegacyDirect;
		output.active_mode = static_cast<uint8_t>(Mode::Legacy);
	}

	const uint32_t reset_faults = input_validity_faults | AllocatorInvalidFault | LogicalMappingInvalidFault;
	output.healthy = output.fault_flags == 0;
	output.dt_used = (output.dt_raw >= kDtMin && output.dt_raw <= kDtMax) ? output.dt_raw : 0.f;

	if ((output.fault_flags & reset_faults) != 0) {
		reset();
		output.reset_count = _reset_count;
	}

	_last_sample_timestamp = input.angular_velocity_timestamp_sample;
	_last_selected = output.u_selected;
#ifndef SAFE_ROLL_DISABLE_PERF
	perf_end(_cycle_perf);
#endif
	return output;
}

SafeRollController::Output SafeRollController::observeLegacy(const Input &input)
{
	return evaluate(input, false);
}

SafeRollController::Output SafeRollController::update(const Input &input)
{
	return evaluate(input, true);
}
